Scene Tree View Plugin (Linux)
==============================

Contents:
- bin/64bit/obs_scene_tree_view.so
- data/locale/*.ini (translations)

Install Instructions
--------------------

User-level install (no sudo):
  mkdir -p ~/.config/obs-studio/plugins/obs_scene_tree_view
  cp bin/64bit/obs_scene_tree_view.so ~/.config/obs-studio/plugins/obs_scene_tree_view/
  mkdir -p ~/.local/share/obs/obs-plugins/obs_scene_tree_view/locale
  cp data/locale/*.ini ~/.local/share/obs/obs-plugins/obs_scene_tree_view/locale/

System-wide install (requires sudo):
  sudo cp bin/64bit/obs_scene_tree_view.so /usr/lib/obs-plugins/
  sudo mkdir -p /usr/share/obs/obs-plugins/obs_scene_tree_view/locale
  sudo cp data/locale/*.ini /usr/share/obs/obs-plugins/obs_scene_tree_view/locale/

After copying, restart OBS Studio and enable:
  View → Docks → Scene Tree View
